package com.example.adminservice.repository;

import com.example.adminservice.model.BusRoute;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BusRouteRepository extends JpaRepository<BusRoute, String> { }
