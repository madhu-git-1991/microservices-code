# admin-service

Admin (master data) microservice for managing BusRoute records.

## Build

mvn clean package

## Run

java -jar target/admin-service-0.0.1-SNAPSHOT.jar

## Docker

docker build -t admin-service:0.0.1 .
docker run -p 8101:8101 --env SPRING_DATASOURCE_URL=jdbc:mysql://host.docker.internal:3306/admin_db admin-service:0.0.1
