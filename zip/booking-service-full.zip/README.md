# Booking Service

Spring Boot microservice for managing bus bookings.

## Build and Run

```bash
mvn clean package
docker build -t booking-service .
docker run -p 8081:8081 booking-service
```
